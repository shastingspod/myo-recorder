var annotated =
[
    [ "_TLMQuaternion", "struct___t_l_m_quaternion.html", null ],
    [ "_TLMVector3", "struct___t_l_m_vector3.html", null ],
    [ "TLMAccelerometerEvent", "interface_t_l_m_accelerometer_event.html", "interface_t_l_m_accelerometer_event" ],
    [ "TLMAngle", "interface_t_l_m_angle.html", "interface_t_l_m_angle" ],
    [ "TLMArmSyncEvent", "interface_t_l_m_arm_sync_event.html", "interface_t_l_m_arm_sync_event" ],
    [ "TLMArmUnsyncEvent", "interface_t_l_m_arm_unsync_event.html", "interface_t_l_m_arm_unsync_event" ],
    [ "TLMEmgEvent", "interface_t_l_m_emg_event.html", "interface_t_l_m_emg_event" ],
    [ "TLMEulerAngles", "interface_t_l_m_euler_angles.html", "interface_t_l_m_euler_angles" ],
    [ "TLMGyroscopeEvent", "interface_t_l_m_gyroscope_event.html", "interface_t_l_m_gyroscope_event" ],
    [ "TLMHub", "interface_t_l_m_hub.html", "interface_t_l_m_hub" ],
    [ "TLMLockEvent", "interface_t_l_m_lock_event.html", "interface_t_l_m_lock_event" ],
    [ "TLMMyo", "interface_t_l_m_myo.html", "interface_t_l_m_myo" ],
    [ "TLMOrientationEvent", "interface_t_l_m_orientation_event.html", "interface_t_l_m_orientation_event" ],
    [ "TLMPose", "interface_t_l_m_pose.html", "interface_t_l_m_pose" ],
    [ "TLMSettingsViewController", "interface_t_l_m_settings_view_controller.html", "interface_t_l_m_settings_view_controller" ],
    [ "TLMUnlockEvent", "interface_t_l_m_unlock_event.html", "interface_t_l_m_unlock_event" ]
];