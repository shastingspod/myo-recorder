var searchData=
[
  ['getting_20started',['Getting Started',['../_getting__started.html',1,'index']]]
];
