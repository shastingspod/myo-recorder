var group__hub_notifications =
[
    [ "TLMHubDidAttachDeviceNotification", "group__hub_notifications.html#ga8dcf693b4a01d2579f32736ac80fcb3f", null ],
    [ "TLMHubDidConnectDeviceNotification", "group__hub_notifications.html#ga54a4187af7cd4161d81b5a0ef43da320", null ],
    [ "TLMHubDidDetachDeviceNotification", "group__hub_notifications.html#ga6169905f5ba10be9c03290642f4570cd", null ],
    [ "TLMHubDidDisconnectDeviceNotification", "group__hub_notifications.html#gacb7fc397586c6834ca35f942a20f266d", null ]
];