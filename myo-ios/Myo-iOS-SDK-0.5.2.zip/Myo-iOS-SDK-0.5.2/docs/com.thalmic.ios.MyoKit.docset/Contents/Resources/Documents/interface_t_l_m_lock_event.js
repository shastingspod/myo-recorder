var interface_t_l_m_lock_event =
[
    [ "myo", "interface_t_l_m_lock_event.html#ad88decdb3441169dcf46ef551ac647d8", null ],
    [ "timestamp", "interface_t_l_m_lock_event.html#a64cb7151688ed81d2a555f2a2bc343eb", null ]
];