var interface_t_l_m_arm_sync_event =
[
    [ "TLMArm", "interface_t_l_m_arm_sync_event.html#a590cb2d979c009f406789285388e8703", [
      [ "TLMArmUnknown", "interface_t_l_m_arm_sync_event.html#a590cb2d979c009f406789285388e8703aa721fde17b91d4c8b25d7934f6edbf0f", null ],
      [ "TLMArmRight", "interface_t_l_m_arm_sync_event.html#a590cb2d979c009f406789285388e8703ae67c0ced92fc44d61aca4649b6e77b2e", null ],
      [ "TLMArmLeft", "interface_t_l_m_arm_sync_event.html#a590cb2d979c009f406789285388e8703af0a6d1d9290b5b4c7cc37c5af91746ae", null ]
    ] ],
    [ "TLMArmXDirection", "interface_t_l_m_arm_sync_event.html#a74a5d0e7ff251686a0ff0eeccf86b269", [
      [ "TLMArmXDirectionUnknown", "interface_t_l_m_arm_sync_event.html#a74a5d0e7ff251686a0ff0eeccf86b269aefa75adecf05fc24efdf98df5b0d0280", null ],
      [ "TLMArmXDirectionTowardWrist", "interface_t_l_m_arm_sync_event.html#a74a5d0e7ff251686a0ff0eeccf86b269a1c404a424eec609cad48d739d435ea60", null ],
      [ "TLMArmXDirectionTowardElbow", "interface_t_l_m_arm_sync_event.html#a74a5d0e7ff251686a0ff0eeccf86b269a182ffb73e9fc772fec4336da19ea15ff", null ]
    ] ],
    [ "arm", "interface_t_l_m_arm_sync_event.html#a1e03ba3302699d650551a8be4cd956ce", null ],
    [ "myo", "interface_t_l_m_arm_sync_event.html#a17d877f2554e2f3507531aaa1d2aae03", null ],
    [ "timestamp", "interface_t_l_m_arm_sync_event.html#a9f2d42f529e3f4414628086d1e1810cc", null ],
    [ "xDirection", "interface_t_l_m_arm_sync_event.html#a615db59a0a3738fce24cd4c47a6f96a3", null ]
];