var interface_t_l_m_angle =
[
    [ "initWithAngle:", "interface_t_l_m_angle.html#a5f44128443deb4128acd6f1c845394ac", null ],
    [ "initWithDegrees:", "interface_t_l_m_angle.html#a1a72f04e30c0bcb143eb6561713b0fe0", null ],
    [ "initWithRadians:", "interface_t_l_m_angle.html#afffc1dd7196abbb46bd4c6a6f426fb24", null ],
    [ "degrees", "interface_t_l_m_angle.html#a5e9cac63bc15eeecf8309d1573b0e747", null ],
    [ "radians", "interface_t_l_m_angle.html#a1cdfede1c67bfae83ac622da174501b8", null ]
];