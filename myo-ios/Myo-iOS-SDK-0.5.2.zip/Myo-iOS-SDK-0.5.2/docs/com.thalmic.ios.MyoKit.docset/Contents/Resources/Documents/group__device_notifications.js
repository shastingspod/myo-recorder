var group__device_notifications =
[
    [ "TLMMyoDidReceiveAccelerometerEventNotification", "group__device_notifications.html#ga2c4c23edbc90e07986237ad1043d492f", null ],
    [ "TLMMyoDidReceiveArmSyncEventNotification", "group__device_notifications.html#gaa05dd085e42571f175937627d20ce38c", null ],
    [ "TLMMyoDidReceiveArmUnsyncEventNotification", "group__device_notifications.html#ga23af804cdfaece44817ce754f76ae9a8", null ],
    [ "TLMMyoDidReceiveEmgEventNotification", "group__device_notifications.html#ga7acbf74c628374ccec908d4817d1c773", null ],
    [ "TLMMyoDidReceiveGyroscopeEventNotification", "group__device_notifications.html#ga47b4d66ef9b447a3d2b0692e6aa5d959", null ],
    [ "TLMMyoDidReceiveLockEventNotification", "group__device_notifications.html#gab294a54c722f97ef7738fc3ca8b4fa71", null ],
    [ "TLMMyoDidReceiveOrientationEventNotification", "group__device_notifications.html#ga3a249eafdc7910e7d34c74a1cd161245", null ],
    [ "TLMMyoDidReceivePoseChangedNotification", "group__device_notifications.html#ga60c40a4ab34fea2c17c3e6d74b58acb2", null ],
    [ "TLMMyoDidReceiveUnlockEventNotification", "group__device_notifications.html#ga2f6d13859e4a223e5f386ae6e80d5395", null ]
];