var hierarchy =
[
    [ "_TLMQuaternion", "struct___t_l_m_quaternion.html", null ],
    [ "_TLMVector3", "struct___t_l_m_vector3.html", null ],
    [ "<NSCopying>", null, [
      [ "TLMAccelerometerEvent", "interface_t_l_m_accelerometer_event.html", null ],
      [ "TLMAngle", "interface_t_l_m_angle.html", null ],
      [ "TLMArmSyncEvent", "interface_t_l_m_arm_sync_event.html", null ],
      [ "TLMArmUnsyncEvent", "interface_t_l_m_arm_unsync_event.html", null ],
      [ "TLMEmgEvent", "interface_t_l_m_emg_event.html", null ],
      [ "TLMEulerAngles", "interface_t_l_m_euler_angles.html", null ],
      [ "TLMGyroscopeEvent", "interface_t_l_m_gyroscope_event.html", null ],
      [ "TLMLockEvent", "interface_t_l_m_lock_event.html", null ],
      [ "TLMOrientationEvent", "interface_t_l_m_orientation_event.html", null ],
      [ "TLMPose", "interface_t_l_m_pose.html", null ],
      [ "TLMUnlockEvent", "interface_t_l_m_unlock_event.html", null ]
    ] ],
    [ "NSObject", null, [
      [ "TLMAccelerometerEvent", "interface_t_l_m_accelerometer_event.html", null ],
      [ "TLMAngle", "interface_t_l_m_angle.html", null ],
      [ "TLMArmSyncEvent", "interface_t_l_m_arm_sync_event.html", null ],
      [ "TLMArmUnsyncEvent", "interface_t_l_m_arm_unsync_event.html", null ],
      [ "TLMEmgEvent", "interface_t_l_m_emg_event.html", null ],
      [ "TLMEulerAngles", "interface_t_l_m_euler_angles.html", null ],
      [ "TLMGyroscopeEvent", "interface_t_l_m_gyroscope_event.html", null ],
      [ "TLMHub", "interface_t_l_m_hub.html", null ],
      [ "TLMLockEvent", "interface_t_l_m_lock_event.html", null ],
      [ "TLMMyo", "interface_t_l_m_myo.html", null ],
      [ "TLMOrientationEvent", "interface_t_l_m_orientation_event.html", null ],
      [ "TLMPose", "interface_t_l_m_pose.html", null ],
      [ "TLMUnlockEvent", "interface_t_l_m_unlock_event.html", null ]
    ] ],
    [ "UIViewController", null, [
      [ "TLMSettingsViewController", "interface_t_l_m_settings_view_controller.html", null ]
    ] ]
];