var searchData=
[
  ['shouldnotifyinbackground',['shouldNotifyInBackground',['../interface_t_l_m_hub.html#a05504d8da60de015b64366d1edc738d8',1,'TLMHub']]],
  ['shouldsendusagedata',['shouldSendUsageData',['../interface_t_l_m_hub.html#a1c2b081ff4a8c9211c9f26fc58a478df',1,'TLMHub']]],
  ['showdonebutton',['showDoneButton',['../interface_t_l_m_settings_view_controller.html#a035a95f9f44a3c6514cc0cc3a2f31e05',1,'TLMSettingsViewController']]],
  ['state',['state',['../interface_t_l_m_myo.html#ac1ea3c5b29fafaae5d91830bb6eda1e1',1,'TLMMyo']]]
];
