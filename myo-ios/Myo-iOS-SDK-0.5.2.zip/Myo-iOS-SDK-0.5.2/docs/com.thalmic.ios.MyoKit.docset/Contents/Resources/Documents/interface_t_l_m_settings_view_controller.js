var interface_t_l_m_settings_view_controller =
[
    [ "showDoneButton", "interface_t_l_m_settings_view_controller.html#a035a95f9f44a3c6514cc0cc3a2f31e05", null ]
];