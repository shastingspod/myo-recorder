var interface_t_l_m_unlock_event =
[
    [ "myo", "interface_t_l_m_unlock_event.html#a4a5aafea8c151dfb9be2268d368452a6", null ],
    [ "timestamp", "interface_t_l_m_unlock_event.html#ad3c0c7ae18b7cd4d2f8f33b786856101", null ]
];