var interface_t_l_m_gyroscope_event =
[
    [ "myo", "interface_t_l_m_gyroscope_event.html#ad1803008938476ec956ccdc78d046bff", null ],
    [ "timestamp", "interface_t_l_m_gyroscope_event.html#ad0957fe4c2386dae193f1bdb77e49572", null ],
    [ "vector", "interface_t_l_m_gyroscope_event.html#a35b35fbacb2444d8cde983b5c66003ac", null ]
];