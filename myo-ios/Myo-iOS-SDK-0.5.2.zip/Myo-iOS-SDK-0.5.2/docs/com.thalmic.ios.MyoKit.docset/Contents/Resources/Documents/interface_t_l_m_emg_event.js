var interface_t_l_m_emg_event =
[
    [ "myo", "interface_t_l_m_emg_event.html#a927c95c1d3c82e81597060ab15260160", null ],
    [ "rawData", "interface_t_l_m_emg_event.html#a7fac6bdf3f8ea4009a71ae1fdaa9fcc9", null ],
    [ "timestamp", "interface_t_l_m_emg_event.html#aa307aa80c753c2eb85998a4f4eb30f00", null ]
];