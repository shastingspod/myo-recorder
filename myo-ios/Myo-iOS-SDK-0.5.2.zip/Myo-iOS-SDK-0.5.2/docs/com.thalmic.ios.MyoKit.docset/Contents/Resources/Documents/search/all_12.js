var searchData=
[
  ['xdirection',['xDirection',['../interface_t_l_m_arm_sync_event.html#a615db59a0a3738fce24cd4c47a6f96a3',1,'TLMArmSyncEvent::xDirection()'],['../interface_t_l_m_myo.html#ad5b9d0a71528a212e405ebb665b9143c',1,'TLMMyo::xDirection()']]]
];
