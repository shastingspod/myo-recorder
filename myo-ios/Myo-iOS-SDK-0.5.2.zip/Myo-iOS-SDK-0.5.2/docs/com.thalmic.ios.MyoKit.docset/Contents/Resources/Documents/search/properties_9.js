var searchData=
[
  ['radians',['radians',['../interface_t_l_m_angle.html#a1cdfede1c67bfae83ac622da174501b8',1,'TLMAngle']]],
  ['rawdata',['rawData',['../interface_t_l_m_emg_event.html#a7fac6bdf3f8ea4009a71ae1fdaa9fcc9',1,'TLMEmgEvent']]],
  ['roll',['roll',['../interface_t_l_m_euler_angles.html#a70dea082d7777b03958ad221216201e7',1,'TLMEulerAngles']]]
];
