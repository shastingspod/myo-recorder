var modules =
[
    [ "NSNotificationCenter Hub Constants", "group__hub_notifications.html", "group__hub_notifications" ],
    [ "NSNotificationCenter Hub Data Key Constants", "group__hub_notification_data_keys.html", "group__hub_notification_data_keys" ],
    [ "NSNotificationCenter Device Constants", "group__device_notifications.html", "group__device_notifications" ],
    [ "NSNotificationCenter Device Data Key Constants", "group__device_notification_data_keys.html", "group__device_notification_data_keys" ]
];