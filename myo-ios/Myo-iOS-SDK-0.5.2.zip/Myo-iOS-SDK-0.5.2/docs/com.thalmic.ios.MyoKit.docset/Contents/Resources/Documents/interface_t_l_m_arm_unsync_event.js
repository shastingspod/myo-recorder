var interface_t_l_m_arm_unsync_event =
[
    [ "myo", "interface_t_l_m_arm_unsync_event.html#a767a1eadbc0ed1bc7e59f130432334b1", null ],
    [ "timestamp", "interface_t_l_m_arm_unsync_event.html#a1051a702eed29a2c3f019f86aa8e03cd", null ]
];