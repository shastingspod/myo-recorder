var searchData=
[
  ['pitch',['pitch',['../interface_t_l_m_euler_angles.html#a4d9040c1c5c5d14eed71c80c82e85765',1,'TLMEulerAngles']]],
  ['pose',['pose',['../interface_t_l_m_myo.html#a322b9e99abc0a46d71c17c4b0afcbbdb',1,'TLMMyo']]]
];
