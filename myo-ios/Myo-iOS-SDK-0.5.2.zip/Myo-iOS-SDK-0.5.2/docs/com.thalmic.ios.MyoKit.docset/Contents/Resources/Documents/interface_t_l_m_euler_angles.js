var interface_t_l_m_euler_angles =
[
    [ "pitch", "interface_t_l_m_euler_angles.html#a4d9040c1c5c5d14eed71c80c82e85765", null ],
    [ "roll", "interface_t_l_m_euler_angles.html#a70dea082d7777b03958ad221216201e7", null ],
    [ "yaw", "interface_t_l_m_euler_angles.html#a36b85cd03a00d4b75fcb61ae28c4f308", null ]
];