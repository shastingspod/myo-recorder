var searchData=
[
  ['setstreamemg_3a',['setStreamEmg:',['../interface_t_l_m_myo.html#aea51af2db61b22057a41648dc0eda580',1,'TLMMyo']]],
  ['settingsinnavigationcontroller',['settingsInNavigationController',['../interface_t_l_m_settings_view_controller.html#a4fcb5b8989223e1178ea3fbfd32fd232',1,'TLMSettingsViewController']]],
  ['settingsinpopovercontroller',['settingsInPopoverController',['../interface_t_l_m_settings_view_controller.html#ab1536c282add649b7e7ea98f0314b927',1,'TLMSettingsViewController']]],
  ['sharedhub',['sharedHub',['../interface_t_l_m_hub.html#a34274c550fa0b5f8d64fbc36df657b1b',1,'TLMHub']]]
];
