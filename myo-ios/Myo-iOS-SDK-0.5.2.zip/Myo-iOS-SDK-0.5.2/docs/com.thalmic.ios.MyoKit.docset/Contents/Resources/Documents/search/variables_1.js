var searchData=
[
  ['tlmhubdidattachdevicenotification',['TLMHubDidAttachDeviceNotification',['../group__hub_notifications.html#ga8dcf693b4a01d2579f32736ac80fcb3f',1,'TLMHub.h']]],
  ['tlmhubdidconnectdevicenotification',['TLMHubDidConnectDeviceNotification',['../group__hub_notifications.html#ga54a4187af7cd4161d81b5a0ef43da320',1,'TLMHub.h']]],
  ['tlmhubdiddetachdevicenotification',['TLMHubDidDetachDeviceNotification',['../group__hub_notifications.html#ga6169905f5ba10be9c03290642f4570cd',1,'TLMHub.h']]],
  ['tlmhubdiddisconnectdevicenotification',['TLMHubDidDisconnectDeviceNotification',['../group__hub_notifications.html#gacb7fc397586c6834ca35f942a20f266d',1,'TLMHub.h']]],
  ['tlmmyodidreceiveaccelerometereventnotification',['TLMMyoDidReceiveAccelerometerEventNotification',['../group__device_notifications.html#ga2c4c23edbc90e07986237ad1043d492f',1,'TLMMyo.h']]],
  ['tlmmyodidreceivearmsynceventnotification',['TLMMyoDidReceiveArmSyncEventNotification',['../group__device_notifications.html#gaa05dd085e42571f175937627d20ce38c',1,'TLMMyo.h']]],
  ['tlmmyodidreceivearmunsynceventnotification',['TLMMyoDidReceiveArmUnsyncEventNotification',['../group__device_notifications.html#ga23af804cdfaece44817ce754f76ae9a8',1,'TLMMyo.h']]],
  ['tlmmyodidreceiveemgeventnotification',['TLMMyoDidReceiveEmgEventNotification',['../group__device_notifications.html#ga7acbf74c628374ccec908d4817d1c773',1,'TLMMyo.h']]],
  ['tlmmyodidreceivegyroscopeeventnotification',['TLMMyoDidReceiveGyroscopeEventNotification',['../group__device_notifications.html#ga47b4d66ef9b447a3d2b0692e6aa5d959',1,'TLMMyo.h']]],
  ['tlmmyodidreceivelockeventnotification',['TLMMyoDidReceiveLockEventNotification',['../group__device_notifications.html#gab294a54c722f97ef7738fc3ca8b4fa71',1,'TLMMyo.h']]],
  ['tlmmyodidreceiveorientationeventnotification',['TLMMyoDidReceiveOrientationEventNotification',['../group__device_notifications.html#ga3a249eafdc7910e7d34c74a1cd161245',1,'TLMMyo.h']]],
  ['tlmmyodidreceiveposechangednotification',['TLMMyoDidReceivePoseChangedNotification',['../group__device_notifications.html#ga60c40a4ab34fea2c17c3e6d74b58acb2',1,'TLMMyo.h']]],
  ['tlmmyodidreceiveunlockeventnotification',['TLMMyoDidReceiveUnlockEventNotification',['../group__device_notifications.html#ga2f6d13859e4a223e5f386ae6e80d5395',1,'TLMMyo.h']]]
];
