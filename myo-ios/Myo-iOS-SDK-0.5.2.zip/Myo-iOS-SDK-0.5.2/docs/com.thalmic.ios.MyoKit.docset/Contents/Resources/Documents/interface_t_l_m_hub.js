var interface_t_l_m_hub =
[
    [ "TLMLockingPolicy", "interface_t_l_m_hub.html#a28258d40419feadc53030e841bfbb06a", [
      [ "TLMLockingPolicyStandard", "interface_t_l_m_hub.html#a28258d40419feadc53030e841bfbb06aa3079996ed5779d6eac909178816001f8", null ],
      [ "TLMLockingPolicyNone", "interface_t_l_m_hub.html#a28258d40419feadc53030e841bfbb06aa30aa751db44b88a2126a28c4b0561349", null ]
    ] ],
    [ "attachByIdentifier:", "interface_t_l_m_hub.html#ab26689abf1cafdb5d1b43725e8c161b0", null ],
    [ "attachToAdjacent", "interface_t_l_m_hub.html#acbce958ba26bd0392fae52a2cd09d60b", null ],
    [ "detachFromMyo:", "interface_t_l_m_hub.html#ad48f9948be7fc01e3250931d20e8de9c", null ],
    [ "myoDevices", "interface_t_l_m_hub.html#a82e3b69a3fcf803d84417f2b8a46ffff", null ],
    [ "applicationIdentifier", "interface_t_l_m_hub.html#afc3ed0a2a752ac37beafb2720591c64d", null ],
    [ "lockingPolicy", "interface_t_l_m_hub.html#a0bdc4dd729fb7d12d6625baeb4d2787a", null ],
    [ "myoConnectionAllowance", "interface_t_l_m_hub.html#af5f3c633a027f9aff62b2c96d730be3a", null ],
    [ "shouldNotifyInBackground", "interface_t_l_m_hub.html#a05504d8da60de015b64366d1edc738d8", null ],
    [ "shouldSendUsageData", "interface_t_l_m_hub.html#a1c2b081ff4a8c9211c9f26fc58a478df", null ]
];