var interface_t_l_m_orientation_event =
[
    [ "myo", "interface_t_l_m_orientation_event.html#a2686377c92c421c64b96dfcd76ad10ce", null ],
    [ "quaternion", "interface_t_l_m_orientation_event.html#a581803fd7425122476fc8d9323354b36", null ],
    [ "timestamp", "interface_t_l_m_orientation_event.html#a27dfb22506d239e08737ded5fa5df80c", null ]
];