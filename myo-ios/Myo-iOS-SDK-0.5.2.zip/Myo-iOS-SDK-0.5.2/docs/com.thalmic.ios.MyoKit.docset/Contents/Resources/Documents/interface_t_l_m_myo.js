var interface_t_l_m_myo =
[
    [ "TLMMyoConnectionState", "interface_t_l_m_myo.html#a2b362051a72b535b2a0c9612f0b9603a", [
      [ "TLMMyoConnectionStateConnected", "interface_t_l_m_myo.html#a2b362051a72b535b2a0c9612f0b9603aa3ed33b4254a8a97c7cab1bb58df1593e", null ],
      [ "TLMMyoConnectionStateConnecting", "interface_t_l_m_myo.html#a2b362051a72b535b2a0c9612f0b9603aa4408eee626472ace6aa9177e0b2e10ad", null ],
      [ "TLMMyoConnectionStateDisconnected", "interface_t_l_m_myo.html#a2b362051a72b535b2a0c9612f0b9603aa028bcd67fb85a1afb7845bcfd36a27e8", null ],
      [ "TLMStreamEmgDisabled", "interface_t_l_m_myo.html#a68c02042b9a26b4c1f1aa2301fc815f1ada360cb7840d2385ad43ef360931e7db", null ],
      [ "TLMStreamEmgEnabled", "interface_t_l_m_myo.html#a68c02042b9a26b4c1f1aa2301fc815f1afeed49f47b50b11687a9d6cb71d080cc", null ]
    ] ],
    [ "TLMUnlockType", "interface_t_l_m_myo.html#a240ec53d598d2f0c39fec12935973e78", [
      [ "TLMUnlockTypeTimed", "interface_t_l_m_myo.html#a240ec53d598d2f0c39fec12935973e78a0ab6fa697dfa7a63e78cda0fc7ff3640", null ],
      [ "TLMUnlockTypeHold", "interface_t_l_m_myo.html#a240ec53d598d2f0c39fec12935973e78a0ad28d8851820a9355f5681925c28351", null ]
    ] ],
    [ "TLMVibrationLength", "interface_t_l_m_myo.html#ae0b6a25b0e4181f1017cd951ea2f80d7", [
      [ "TLMVibrationLengthShort", "interface_t_l_m_myo.html#ae0b6a25b0e4181f1017cd951ea2f80d7a477bfb068b66c900eb43791b6fb609f7", null ],
      [ "TLMVibrationLengthMedium", "interface_t_l_m_myo.html#ae0b6a25b0e4181f1017cd951ea2f80d7a4e6f08c9567d132a679f237398174a42", null ],
      [ "TLMVibrationLengthLong", "interface_t_l_m_myo.html#ae0b6a25b0e4181f1017cd951ea2f80d7a7ec7c417839413013a1068c519f33401", null ]
    ] ],
    [ "indicateUserAction", "interface_t_l_m_myo.html#ac5e48e4df92ce61d21dee7ccacc677df", null ],
    [ "lock", "interface_t_l_m_myo.html#aa3c4352180fea08a41c37d4398d3908d", null ],
    [ "readSignalStrengthWithResult:", "interface_t_l_m_myo.html#ad1abbf539a8d0916f56fdbb6213dda70", null ],
    [ "setStreamEmg:", "interface_t_l_m_myo.html#aea51af2db61b22057a41648dc0eda580", null ],
    [ "unlockWithType:", "interface_t_l_m_myo.html#a05cee0360ee6a2d9d279ee3776c36b42", null ],
    [ "vibrateWithLength:", "interface_t_l_m_myo.html#a64ed23411c045a18544d59219663e425", null ],
    [ "arm", "interface_t_l_m_myo.html#acd76dc38248f7d96f8f9b87c7db55242", null ],
    [ "identifier", "interface_t_l_m_myo.html#aab917453673e34df8c96daa9746e00e6", null ],
    [ "isLocked", "interface_t_l_m_myo.html#a31259b76f71d4793539029e7aca896ff", null ],
    [ "name", "interface_t_l_m_myo.html#a554bd2221f359d77264019c9c09a3cea", null ],
    [ "orientation", "interface_t_l_m_myo.html#a5464707c14426d7e6df51443c65d431d", null ],
    [ "pose", "interface_t_l_m_myo.html#a322b9e99abc0a46d71c17c4b0afcbbdb", null ],
    [ "state", "interface_t_l_m_myo.html#ac1ea3c5b29fafaae5d91830bb6eda1e1", null ],
    [ "xDirection", "interface_t_l_m_myo.html#ad5b9d0a71528a212e405ebb665b9143c", null ]
];