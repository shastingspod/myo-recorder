var files =
[
    [ "MyoKit.h", "_myo_kit_8h_source.html", null ],
    [ "TLMAccelerometerEvent.h", "_t_l_m_accelerometer_event_8h_source.html", null ],
    [ "TLMAngle.h", "_t_l_m_angle_8h_source.html", null ],
    [ "TLMArmSyncEvent.h", "_t_l_m_arm_sync_event_8h_source.html", null ],
    [ "TLMArmUnsyncEvent.h", "_t_l_m_arm_unsync_event_8h_source.html", null ],
    [ "TLMEmgEvent.h", "_t_l_m_emg_event_8h_source.html", null ],
    [ "TLMEulerAngles.h", "_t_l_m_euler_angles_8h_source.html", null ],
    [ "TLMGyroscopeEvent.h", "_t_l_m_gyroscope_event_8h_source.html", null ],
    [ "TLMHub.h", "_t_l_m_hub_8h_source.html", null ],
    [ "TLMLockEvent.h", "_t_l_m_lock_event_8h_source.html", null ],
    [ "TLMMath.h", "_t_l_m_math_8h_source.html", null ],
    [ "TLMMyo.h", "_t_l_m_myo_8h_source.html", null ],
    [ "TLMOrientationEvent.h", "_t_l_m_orientation_event_8h_source.html", null ],
    [ "TLMPose.h", "_t_l_m_pose_8h_source.html", null ],
    [ "TLMSettingsViewController.h", "_t_l_m_settings_view_controller_8h_source.html", null ],
    [ "TLMUnlockEvent.h", "_t_l_m_unlock_event_8h_source.html", null ]
];