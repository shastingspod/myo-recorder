var index =
[
    [ "Getting Started", "_getting__started.html", null ],
    [ "Release Notes And Known Issues", "release-notes.html", [
      [ "Known Issues and Limitations", "release-notes.html#known-issues", null ],
      [ "Release History", "release-notes.html#release-history", null ]
    ] ]
];