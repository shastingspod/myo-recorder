var searchData=
[
  ['vector',['vector',['../interface_t_l_m_accelerometer_event.html#a432258da57c8b280c7a942d3b9f8eb4a',1,'TLMAccelerometerEvent::vector()'],['../interface_t_l_m_gyroscope_event.html#a35b35fbacb2444d8cde983b5c66003ac',1,'TLMGyroscopeEvent::vector()']]],
  ['vibratewithlength_3a',['vibrateWithLength:',['../interface_t_l_m_myo.html#a64ed23411c045a18544d59219663e425',1,'TLMMyo']]]
];
