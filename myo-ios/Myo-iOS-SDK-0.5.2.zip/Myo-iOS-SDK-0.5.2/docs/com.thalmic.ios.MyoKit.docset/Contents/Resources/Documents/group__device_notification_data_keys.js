var group__device_notification_data_keys =
[
    [ "kTLMKeyAccelerometerEvent", "group__device_notification_data_keys.html#gae99703210cb198d2f6a70a61d22eab8a", null ],
    [ "kTLMKeyArmSyncEvent", "group__device_notification_data_keys.html#gaeac01c0a91528a9309a77d0c397c8a45", null ],
    [ "kTLMKeyArmUnsyncEvent", "group__device_notification_data_keys.html#ga7f1fa1d164cb435daf5c3bce81451364", null ],
    [ "kTLMKeyEMGEvent", "group__device_notification_data_keys.html#gacc4a4d17e22893ecc100ffff7b65b662", null ],
    [ "kTLMKeyGyroscopeEvent", "group__device_notification_data_keys.html#gae34b6c69ea27828f8cc64995b5e2d3c0", null ],
    [ "kTLMKeyLockEvent", "group__device_notification_data_keys.html#ga3e78e0159dd42b94aab667d157b2ce35", null ],
    [ "kTLMKeyOrientationEvent", "group__device_notification_data_keys.html#ga3e92370f7fdbbb68e1b67219f3aade01", null ],
    [ "kTLMKeyPose", "group__device_notification_data_keys.html#gafa3c7bb0aed658e613c0c85c93861255", null ],
    [ "kTLMKeyUnlockEvent", "group__device_notification_data_keys.html#ga504c37650a9022f9693d5c1d3ba81b75", null ]
];