var interface_t_l_m_pose =
[
    [ "TLMPoseType", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3", [
      [ "TLMPoseTypeRest", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3ad6d5c4bbcbde5bb3bb32697f98d6bca8", null ],
      [ "TLMPoseTypeFist", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3ad06488ffa89368777cd5e05b0dde3b6e", null ],
      [ "TLMPoseTypeWaveIn", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3a14bd261ec346773d7e83641fedb2e669", null ],
      [ "TLMPoseTypeWaveOut", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3a91f3c69991f0f860df7082696ff83e54", null ],
      [ "TLMPoseTypeFingersSpread", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3a7e4b89d5d88e85d9c3dd6772762a704f", null ],
      [ "TLMPoseTypeDoubleTap", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3a0c246b4eb76fe16f40cb509967af55dd", null ],
      [ "TLMPoseTypeUnknown", "interface_t_l_m_pose.html#aff089ea690d4db762152032979ad2ed3ab1788e1cb02cc2d16280e481521d84ba", null ]
    ] ],
    [ "myo", "interface_t_l_m_pose.html#a3936f4f64aff65c5d92eb5a5da6891f8", null ],
    [ "timestamp", "interface_t_l_m_pose.html#aeabc9e3edf23ac4bcdac71d27c7e6607", null ],
    [ "type", "interface_t_l_m_pose.html#a16841d7ca84dd0a9eb2703df48b14d3a", null ]
];