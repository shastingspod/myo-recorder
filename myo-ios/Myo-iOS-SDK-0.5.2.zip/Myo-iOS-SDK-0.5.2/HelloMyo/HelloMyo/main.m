//
//  main.m
//  HelloMyo
//
//  Copyright (C) 2013 Thalmic Labs Inc.
//  Distributed under the Myo SDK license agreement. See LICENSE.txt.
//

#import <UIKit/UIKit.h>

#import "TLHMAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TLHMAppDelegate class]));
    }
}
